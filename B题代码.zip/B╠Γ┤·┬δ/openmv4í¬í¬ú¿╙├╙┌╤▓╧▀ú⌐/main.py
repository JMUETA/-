import sensor, image, time, math , pyb ,json ,struct,lcd
from pyb import UART,LED,Pin
from struct import pack, unpack
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.set_brightness(-2)
sensor.set_contrast(3)
sensor.set_saturation(3)
sensor.skip_frames(time = 500)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
clock = time.clock()
uart = UART(3, 115200)
uart.init(115200, bits=8, parity=None, stop=1, timeout_char=1000)
led1 = LED(1)
led2 = LED(2)
led3 = LED(3)
rlmin=0
rlmax=39
ramin=-31
ramax=48
rbmin=-46
rbmax=47
hlmin=0
hlmax=13
hamin=-14
hamax=16
hbmin=-17
hbmax=10
thresholds = [(rlmin,rlmax,ramin,ramax,rbmin,rbmax),
			  (hlmin,hlmax,hamin,hamax,hbmin,hbmax)]
ROIS = [
		(00, 0, 20, 120, 1),
		(70, 0, 20, 120, 1),
		(140, 0, 20, 120, 1)
	   ]
WorkMode=0
wheel_flag_b=0
rx_mode=0
flag_wheel=0
flag_blob_b_2=0
down_flag=0
class receive(object):
	uart_buf = []
	state = 0
	rx_data=0
R=receive()
def rx_receive(data):
	if R.state==0:
		if data == 0xAA:
			R.state = 1
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==1:
		if data == 0x55:
			R.state = 2
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==2:
		if data == 19:
			R.state = 3
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==3:
		if data == 0x01:
			R.state = 4
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==4:
		R.state =5
		R.uart_buf.append(data)
	elif R.state==5:
		if data== (R.uart_buf[0] + R.uart_buf[1] + R.uart_buf[2] + R.uart_buf[3] + R.uart_buf[4])%256 :
			R.state = 0
			R.uart_buf.append(data)
			R.rx_data=R.uart_buf[4]
			R.uart_buf=[]
		else:
			R.state = 0
def uart_mode_seclet():
	find_mode = R.rx_data
	R.rx_data = 0
	return find_mode
def uart_read_buf(uart):
	i = 0
	buf_size = uart.any()
	while i<buf_size:
		rx_receive(uart.readchar())
		i = i + 1
def partition_find_line(picture,uart):
	global wheel_flag_b
	tx_buf = [0,0,0,0,0,0,0,0,0,0,0,0]
	blobs_num=0
	for r in ROIS:
		img = picture
		blobs = img.find_blobs([thresholds[0]], roi=r[0:4], merge=True)
		blobs_num = blobs_num + 4
		if blobs:
			most_pixels = 0
			largest_blob = 0
			for i in range(len(blobs)):
				if blobs[i].pixels() > most_pixels:
					most_pixels = blobs[i].pixels()
					largest_blob = i
			img.draw_rectangle(blobs[largest_blob].rect())
			img.draw_cross(blobs[largest_blob].cx(),
						   blobs[largest_blob].cy())
			tx_buf[0 + blobs_num-4] = blobs[largest_blob].cx()
			tx_buf[1 + blobs_num-4] = blobs[largest_blob].cy()
			tx_buf[2 + blobs_num-4] = blobs[largest_blob].w()
			tx_buf[3 + blobs_num-4] = blobs[largest_blob].h()
		else:
			tx_buf[0 + blobs_num-4] = 0xff
			tx_buf[1 + blobs_num-4] = 0xff
			tx_buf[2 + blobs_num-4] = 0xff
			tx_buf[3 + blobs_num-4] = 0xff
	cx_1=tx_buf[0]
	cy_1 =tx_buf[1]
	w_1=tx_buf[2]
	h_1 =tx_buf[3]
	cx_2=tx_buf[4]
	cy_2 =tx_buf[5]
	w_2=tx_buf[6]
	h_2 =tx_buf[7]
	cx_3=tx_buf[8]
	cy_3 =tx_buf[9]
	w_3=tx_buf[10]
	h_3 =tx_buf[11]
	if wheel_flag_b==1:
		judge_wheel_1(cy_3,w_1,h_1,w_2,h_2,w_3,h_3)
	if wheel_flag_b==4:
		judge_wheel_3(cy_3,w_1,h_1,w_2,h_2,w_3,h_3)
	smooth(cx_1,cy_1,w_1,h_1,cx_2,cy_2,w_2,h_2,cx_3,cy_3,w_3,h_3)
def find_max(blobs):
	max_size = 0
	for blob in blobs:
		if blob.w() * blob.h() > max_size:
			max_blob = blob
			max_size = blob.w()*blob.h()
	return max_blob
def judge_wheel_1(cy_3,w_1,h_1,w_2,h_2,w_3,h_3):
	global flag_wheel
	global wheel_flag_b
	global down_flag
	led3.on()
	if 10<w_1<255 and 40<h_1 <255 :
		if down_flag==0:
			down_flag=1
			flag_wheel=1
			led3.off()
			uart.write(pack_down_data(1))
			wheel_flag_b=2
def judge_wheel_3(cy_3,w_1,h_1,w_2,h_2,w_3,h_3):
	global flag_wheel
	global wheel_flag_b
	global down_flag
	if 10<w_1<255 and 40<h_1 <255 :
		uart.write(pack_down_data(3))
		wheel_flag_b=0
def judege_wheel_2(img,uart):
	global wheel_flag_b
	global flag_blob_b_2
	led2.on()
	if flag_blob_b_2==0:
		flag_blob_b_2=1
	if flag_blob_b_2==1:
		blobs = img.find_blobs([thresholds[1]], roi=[0,0,160,40],pixels_threshold=100, area_threshold=100, merge=True)
		if blobs:
			led2.off()
			max_blob = find_max(blobs)
			img.draw_rectangle(max_blob.rect())
			img.draw_cross(max_blob.cx(), max_blob.cy())
			uart.write(pack_wheel_data(max_blob.cx()))
			led1.on()
def pack_wheel_data(flag):
	datalist = [0xAA,0x55,0x17,0x01,flag]
	datalist.append(sum_checkout(datalist))
	data = bytearray(datalist)
	return data
def pack_down_data(flag):
	datalist = [0xAA,0x55,0x18,0x01,flag]
	datalist.append(sum_checkout(datalist))
	data = bytearray(datalist)
	print(datalist)
	return data
def smooth(cx_1,cy_1,w_1,h_1,cx_2,cy_2,w_2,h_2,cx_3,cy_3,w_3,h_3):
	k=0
	if h_1>20 or w_1<15:
		cy_1=0xff
	if h_2>20 or w_2<15:
		cy_2=0xff
	if h_3>20 or w_3<15:
		cy_3=0xff
	if h_1<=20 and h_2<=20 and h_3<=20:
		if w_1>15 and w_2>15 and w_3>15:
			k=(cy_1-cy_2)/(cx_1-cx_2)
	elif h_1<=20 and h_2<=20 and h_3==0xff:
		if w_1>15 and w_2>15 and w_3==0xff:
			k=(cy_1-cy_2)/(cx_1-cx_2)
	elif h_1==0xff and h_2<=20 and h_3<=20:
		if w_1==0xff and w_2>15 and w_3>15:
			k=(cy_2-cy_3)/(cx_2-cx_3)
	elif h_1<=20 and h_2==0xff and h_3<=20:
		if w_1>15 and w_2==0xff and w_3>15:
			k=(cy_1-cy_3)/(cx_1-cx_3)
	elif h_1==0xff and h_2==0xff and h_3<=20:
		if w_1==0xff and w_2==0xff and w_3>15:
			k=0xff
	elif h_1<=20 and h_2==0xff and h_3==0xff:
		if w_1>15 and w_2==0xff and w_3==0xff:
			k=0xff
	elif h_1==0xff and h_2<=20 and h_3==0xff:
		if w_1==0xff and w_2>15 and w_3==0xff:
			k=0xff
	elif h_1==0xff and h_2==0xff and h_3==0xff:
		if w_1==0xff and w_2==0xff and w_3==0xff:
			k=0xff
	else:
		k=0xff
	if k!=0xff:
		k = int(math.degrees(-math.atan(k)))+37
	uart.write(pack_line_data(cy_1,cy_2,cy_3,k))
def pack_line_data(cy_1,cy_2,cy_3,k):
	datalist = [0xAA,0x55,0x12,0x04,cy_1,cy_2,cy_3,k]
	datalist.append(sum_checkout(datalist))
	data = bytearray(datalist)
	return data
def sum_checkout(data_list):
	data_sum = 0
	for temp in data_list:
		data_sum += temp
	return (data_sum)
while(WorkMode==0):
	clock.tick()
	img = sensor.snapshot()
	uart_read_buf(uart)
	rx_mode = uart_mode_seclet()
	if rx_mode != 0:
		WorkMode = rx_mode
		if WorkMode ==11:
			sensor.set_pixformat(sensor.RGB565)
		if WorkMode ==12:
			sensor.set_pixformat(sensor.RGB565)
		if WorkMode ==13:
			sensor.set_pixformat(sensor.GRAYSCALE)
while(WorkMode ==11):
	pass
while(WorkMode ==12):
	pass
while(WorkMode ==13):
	clock.tick()
	img = sensor.snapshot()
	uart_read_buf(uart)
	rx_mode_13 = uart_mode_seclet()
	if rx_mode_13 ==100:
		wheel_flag_b=1
	if rx_mode_13 ==103:
		wheel_flag_b=0
		flag_blob_b_2=0
		sensor.set_pixformat(sensor.GRAYSCALE)
	if rx_mode_13==104:
		wheel_flag_b=4
	if wheel_flag_b==2:
		judege_wheel_2(img,uart)
	if wheel_flag_b!=2:
		led1.on()
		partition_find_line(img,uart)
