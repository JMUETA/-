import sensor,image,time,math
from pyb import UART
yellow_threshold   = (100, 0, -128, 125, 16, 127)
quar_threshold = (100, 8, -2, 127, -6, -29)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(100)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
count_change = 0
change_flag = False
bar_flag = False
uart = UART(3, 115200)
uart.init(115200, bits=8, parity=None, stop=1, timeout_char=1000)
quar_flag = True
rx_mode = 0
bar_count = 0
def sum_checkout(data_list):
	data_sum = 0
	for temp in data_list:
		data_sum += temp
	return (data_sum)
class receive(object):
	uart_buf = []
	state = 0
	rx_data=0
R=receive()
def rx_receive(data):
	if R.state==0:
		if data == 0xAA:
			R.state = 1
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==1:
		if data == 0x55:
			R.state = 2
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==2:
		if data == 0xff:
			R.state = 3
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==3:
		if data == 0x01:
			R.state = 4
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==4:
		if data == 0x01 or data == 0x02 or data == 0x03:
			R.state =5
			R.uart_buf.append(data)
		else:
			R.state = 0
	elif R.state==5:
		if data== (R.uart_buf[0] + R.uart_buf[1] + R.uart_buf[2] + R.uart_buf[3] + R.uart_buf[4])%256 :
			R.state = 0
			R.uart_buf.append(data)
			R.rx_data=R.uart_buf[4]
			print(R.rx_data)
			R.uart_buf=[]
		else:
			R.state = 0
def uart_mode_seclet():
	find_mode = R.rx_data
	R.rx_data = 0
	return find_mode
def uart_read_buf(uart):
	i = 0
	buf_size = uart.any()
	while i<buf_size:
		rx_receive(uart.readchar())
		i = i + 1
def find_max(blobs):
	max_size = 0
	for blob in blobs:
		if blob.w() * blob.h() > max_size:
			max_blob = blob
			max_size = blob.w()*blob.h()
	return max_blob,max_size
def communcation_write(model):
	head = [0xaa,0x55,0xff,0x01]
	if model==0:
		motion_bit = [0x00]
	elif model==1:
		motion_bit = [0x01]
	elif model==2:
		motion_bit = [0x02]
	check_sum = [sum(head + motion_bit)%256]
	data = head + motion_bit + check_sum
	msg = bytearray(data)
	uart.write(msg)
word_mode = 0
while(1):
	img0 = sensor.snapshot()
	uart_read_buf(uart)
	rx_mode1 = uart_mode_seclet()
	if(rx_mode1 != 0):
		word_mode = rx_mode1
	if word_mode==2:
		break
	if word_mode==1:
		img0.rotation_corr( z_rotation=90)
		img0.median(1, percentile=0.5)
		blobs = img0.find_blobs([yellow_threshold])
		if blobs:
			max_blob,max_size = find_max(blobs)
			density = max_blob.density()
			if max_size > 3000 and density>0.40:
				communcation_write(1)
				img0.laplacian(1, sharpen=True)
				img0.save('1_1.png')
				print('get')
				break
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QVGA)
sensor.skip_frames(30)
sensor.set_auto_gain(False)
print('two_quar')
send_flag3 = True
ewm_off = True
while(ewm_off):
	img1 = sensor.snapshot()
	uart_read_buf(uart)
	rx_mode3 = uart_mode_seclet()
	if(rx_mode3 != 0):
		word_mode = rx_mode3
	if word_mode == 3:
		ewm_off = False
	b_flag = False
	img1.rotation_corr(z_rotation=90)
	blobs = img1.find_blobs([quar_threshold])
	if blobs:
		max_blob,max_size = find_max(blobs)
		density = max_blob.density()
		if max_size > 4000 and density>0.35:
			quar_flag = False
			if send_flag3:
				send_flag3 = False
			img1.draw_rectangle(max_blob.rect())
			img1.laplacian(1, sharpen=True)
			img1.save('2_1.bmp')
	for code in img1.find_qrcodes():
		print(code)
		b_flag = True
		img1.laplacian(1, sharpen=True)
		img1.save('2_1.bmp')
		ewm_off = False
print('second_tiaoxingma')
while(1):
	img0 = sensor.snapshot()
	img0.rotation_corr( z_rotation=90)
	img0.median(1, percentile=0.5)
	blobs = img0.find_blobs([yellow_threshold])
	if blobs:
		max_blob,max_size = find_max(blobs)
		density = max_blob.density()
		if max_size > 3000 and density>0.40:
			communcation_write(1)
			img0.laplacian(1, sharpen=True)
			img0.save('1_2.png')
			print('get1')
			break
