#include "Headfile.h"
#include "Key.h"

void Key_Init(void)
{
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
  GPIODirModeSet(GPIO_PORTF_BASE, GPIO_PIN_4,GPIO_DIR_MODE_IN);//KEY
  GPIOPadConfigSet(GPIO_PORTF_BASE,GPIO_PIN_4,GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);
}

int16_t Page_Number=0;
bool Key_Scan()
{
  if(QuadKey2==0)
  {
    delay_ms(10);
    if(QuadKey2==0)
    {
      Page_Number++;
      if(Page_Number<0) Page_Number=13;
      LCD_CLS();
    }
  }
  return TRUE;
}

void display()
{
  extern uint16_t UWB_data;
  if(Page_Number==0)
  {
//    LCD_P8x16Str(0,0,"Mode:");         
//    LCD_P8x16Str(0,3,"manipul:");
    write_8_16_number(0,0,UWB_data);
  }
 
}

