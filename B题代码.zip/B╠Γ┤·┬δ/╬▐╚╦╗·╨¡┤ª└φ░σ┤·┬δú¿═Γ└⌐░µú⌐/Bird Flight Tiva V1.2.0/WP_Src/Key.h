#ifndef __KEY_H__
#define __KEY_H__

#define QuadKey2  GPIOPinRead(GPIO_PORTF_BASE , GPIO_PIN_4)

void Key_Init(void);
void display(void);
bool Key_Scan(void);
extern int16_t Page_Number;

#endif


