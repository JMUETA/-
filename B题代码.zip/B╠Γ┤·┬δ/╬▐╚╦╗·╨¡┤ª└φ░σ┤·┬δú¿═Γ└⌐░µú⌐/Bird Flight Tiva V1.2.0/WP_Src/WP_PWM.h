#ifndef __WP_PWM_H__
#define __WP_PWM_H__




void Init_PWM(void);
void PWM_Output(uint16_t width1,uint16_t width2,uint16_t width3,uint16_t width4);
void Servo_control(void);

#endif


