#include "Headfile.h"
u8 Boma_bit[4]={0};
char temp=0x00;
char Boma_mode=0;
void boma_Init(void)
{
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
  GPIODirModeSet(GPIO_PORTD_BASE, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3,GPIO_DIR_MODE_IN);//SW1
  GPIOPadConfigSet(GPIO_PORTD_BASE,GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3,GPIO_STRENGTH_2MA,GPIO_PIN_TYPE_STD_WPU);
}

//���밴λ����u8������
u8 Boma_bit_move(void)
{
  u8 i=0;
  temp=0x00;
  Boma_bit[0]= GPIOPinRead(GPIO_PORTD_BASE , GPIO_PIN_0);//b1
  Boma_bit[1]= GPIOPinRead(GPIO_PORTD_BASE , GPIO_PIN_1);//b2
  Boma_bit[2]= GPIOPinRead(GPIO_PORTD_BASE , GPIO_PIN_2);//b3
  Boma_bit[3]= GPIOPinRead(GPIO_PORTD_BASE , GPIO_PIN_3);//b4 h
  for(i=0;i<4;i++)//bit[0] ���λ
  {
    temp|=Boma_bit[3-i];
  }
  return temp;
}

void boma()
{
  Boma_mode=Boma_bit_move();
  if((boma1==0)&&(boma2==0)&&(boma3==0)&&(boma4==0))
  {
    
    LCD_P8x16Char(60,0,'0'); 
    LCD_P8x16Str(65,3,"natural");
    PWM_Output(0,0,0,0); 
  }
  else if((!(boma1==0))&&(boma2==0)&&(boma3==0)&&(boma4==0))//1
  {
    LCD_P8x16Char(60,0,'1'); 
    LCD_P8x16Str(65,3,"open   ");
    PWM_Output(1850,0,0,0);//ռ�ձ�Խ��צ���ſ�
    Percontroller_Send(32,Boma_mode);//���͵�ǰ����ģʽ���ɿ�
  }
  if((boma1==0)&&(!(boma2==0))&&(boma3==0)&&(boma4==0))//2
  {
    u8 i=0;
    LCD_P8x16Char(60,0,'2'); 
    LCD_P8x16Str(65,3,"close  ");
    for(i=0;i<5;i++)
    { 
      PWM_Output((-100)*i+1850,0,0,0);//צ�ӱպ�
    }
    Percontroller_Send(32,Boma_mode);
  }
  if((!(boma1==0))&&(!(boma2==0))&&(boma3==0)&&(boma4==0))//3
  {
    LCD_P8x16Char(60,0,'3'); 
    Percontroller_Send(32,Boma_mode);
    
    
  }
}