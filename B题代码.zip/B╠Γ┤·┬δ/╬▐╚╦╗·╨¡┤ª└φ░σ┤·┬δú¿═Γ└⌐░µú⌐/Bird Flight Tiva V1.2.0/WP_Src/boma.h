#ifndef __BOMA_H
#define __BOMA_H

void boma_Init(void);
void boma();
u8 Boma_bit_move(void);
extern void Percontroller_Send(u8 tx_mode,u8 data_send);

#define boma1  GPIOPinRead(GPIO_PORTD_BASE , GPIO_PIN_0)
#define boma2  GPIOPinRead(GPIO_PORTD_BASE , GPIO_PIN_1)
#define boma3  GPIOPinRead(GPIO_PORTD_BASE , GPIO_PIN_2)
#define boma4  GPIOPinRead(GPIO_PORTD_BASE , GPIO_PIN_3)//h







#endif