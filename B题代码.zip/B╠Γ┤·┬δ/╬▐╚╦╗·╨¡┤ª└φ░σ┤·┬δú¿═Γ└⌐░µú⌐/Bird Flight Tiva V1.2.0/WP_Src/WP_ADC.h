#ifndef __WP_ADC_H__
#define __WP_ADC_H__


void ADC_Init(void);   
float ADC_StartSample(uint8_t num);  



#endif
