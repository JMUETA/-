#include "UWB.h"
#include "Usart.h"


unsigned char CharToHex(unsigned char bHex)
{
  if((bHex>0)&&(bHex<=9))
  {
    bHex += 0x30;
  }
  else if((bHex>=10)&&(bHex<=15))//Capital
  {
    bHex += 0x37;
  }
  else
  {
    bHex = 0xff;
  }
  return bHex;
}

unsigned char HexToChar(unsigned char bChar)
{
  if((bChar>=0x30)&&(bChar<=0x39))
  {
    bChar -= 0x30;
  }
  else if((bChar>=0x41)&&(bChar<=0x46)) // Capital
  {
    bChar -= 0x37;
  }
  else if((bChar>=0x61)&&(bChar<=0x66)) //little case
  {
    bChar -= 0x57;
  }
  else
  {
    bChar = 0xff;
  }
  return bChar;
}



uint16_t UWB_data = 0;
u8 UWB_data_buf[8] = {0};
void UWB_receive(u8 data)
{
  static u8 UWB_step = 0;
  //static u8 UWB_data_buf[8] = {0};
  
  u8 i = 0;
  
  if(UWB_step == 0 && data == 'm')
  {
//    for(i=0;i<8;i++)
//    {
//      UWB_data_buf[i] = 0;
//    }
    UWB_step ++;
  }
  else if(UWB_step == 1 && (data == 'c' || data == 'r'))
  {
    UWB_step ++;
  }
  else if(UWB_step == 2 && data == 0x20)//�ո�
  {
    UWB_step ++;
  }
  else if(UWB_step == 3 && data == '0')
  {
    UWB_step ++;
  }
  else if(UWB_step == 4 && data == '1')
  {
    UWB_step ++;
  }
  else if(UWB_step == 5 && data == 0x20)
  {
    UWB_step ++;
  }
  else if(UWB_step == 6)
  {
    UWB_data_buf[0] = data;
    UWB_step ++;
  }
  else if(UWB_step == 7)
  {
    UWB_data_buf[1] = data;
    UWB_step ++;
  }
  else if(UWB_step == 8)
  {
    UWB_data_buf[2] = data;
    UWB_step ++;
  }
  else if(UWB_step == 9)
  {
    UWB_data_buf[3] = data;
    UWB_step ++;
  }
  else if(UWB_step == 10)
  {
    UWB_data_buf[4] = data;
    UWB_step ++;
  }
  else if(UWB_step == 11)
  {
    UWB_data_buf[5] = data;
    UWB_step ++;
  }
  else if(UWB_step == 12)
  {
    UWB_data_buf[6] = data;
    UWB_step ++;
  }
  else if(UWB_step == 13)
  {
    UWB_data_buf[7] = data;
    UWB_step ++;
  }
  else if(UWB_step == 14 && data == 0x20)
  {
    for(i=0;i<8;i++)//�ַ�תʮ������
    {
      UWB_data_buf[i] = HexToChar(UWB_data_buf[i]);
    }
    
    UWB_data = UWB_data_buf[4] << 12;
    UWB_data = UWB_data | UWB_data_buf[5] << 8;
    UWB_data = UWB_data | UWB_data_buf[6] << 4;
    UWB_data = UWB_data | UWB_data_buf[7];
    
    
    for(i=0;i<4;i++)//�ж�ǰ��λ�Ƿ�Ϊ0��Ϊ0��ֵ0xFFFF
    {
      if(UWB_data_buf[i] > 0)//����0
      {
        UWB_data = 0xFFFF;
      }
    }
    UWB_step = 0;
  }
  
  
  else
  {
    UWB_step = 0;
  }
}







