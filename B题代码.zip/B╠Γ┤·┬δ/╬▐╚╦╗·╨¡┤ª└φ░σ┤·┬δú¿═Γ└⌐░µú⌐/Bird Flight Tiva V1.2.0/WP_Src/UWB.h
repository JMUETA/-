#ifndef __UWB_H__
#define __UWB_H__

#include <dataTy.h>

void UWB_receive(u8 data);

#endif


