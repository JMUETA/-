#ifndef __HEADFILE_H__
#define __HEADFILE_H__


#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <dataTy.h>

#define BYTE0(dwTemp)       ( *( (char *)(&dwTemp)      ) )
#define BYTE1(dwTemp)       ( *( (char *)(&dwTemp) + 1) )
#define BYTE2(dwTemp)       ( *( (char *)(&dwTemp) + 2) )
#define BYTE3(dwTemp)       ( *( (char *)(&dwTemp) + 3) )


#define  USER_INT0  0x00
#define  USER_INT1  0x20
#define  USER_INT2  0x40
#define  USER_INT3  0x60
#define  USER_INT4  0x80
#define  USER_INT5  0xA0
#define  USER_INT6  0xD0
#define  USER_INT7  0xE0

#define ABS(X)  (((X)>0)?(X):-(X))
#define MAX(a,b)  ((a)>(b)?(a):(b))
#define Imu_Sampling_Freq  200
#define WP_Duty_Freq  200
#define WP_Duty_Dt  (1.0f/WP_Duty_Freq)



//typedef   signed        char int8;
//typedef unsigned        char u8;
//typedef unsigned        char uint8;
//typedef unsigned        char byte;
//typedef   signed short  int int16;
//typedef unsigned short  int uint16;
//typedef unsigned short  int u16;
//typedef unsigned long   int u32; 


#define _YAW    0
#define _PITCH  1
#define _ROLL   2

#define Delta 0.005f

#include "hw_memmap.h"
#include "hw_types.h"
#include "hw_ints.h"
#include "debug.h"
#include "fpu.h"
#include "gpio.h"
#include "pin_map.h"
#include "pwm.h"
#include "rom.h"
#include "sysctl.h"
#include "uart.h"
#include "interrupt.h"
#include "timer.h"
#include "hw_gpio.h"
#include "eeprom.h"
/////////////////////////
#include "WP_DataType.h"
#include "Usart.h"
#include "uartstdio.h"
//#include "RDroneSudio.h"
#include "Time.h"
#include "Time_Cnt.h"
#include "Schedule.h"
#include "oled.h"
#include "wp_flash.h"
#include "Ringbuf.h"
#include "WP_PWM.h"
//#include "Remote.h"
#include "Key.h"
#include "WP_ADC.h"
#include "Bling.h"
#include "SYSTEM.h"
#include "myiic.h"
#include "boma.h"
#include "voltage.h"


#endif

