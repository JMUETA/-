#ifndef _VOLTAGE_H
#define _VOLTAGE_H

u16 Get_Adc_Average(void);




#endif