#include "Headfile.h"
#define N 10
float Get_value[N]={0};
u16 Get_Adc_Average()
{
  static u8 i=0;
  u16 count=0;
  u8 sum=0;
  Get_value[i++]= ADC_StartSample(0);
  if(i==N) 
  { i=0;
    for(count=0;count<N;count++)
    {
      sum+=Get_value[count];
    }
  }
    return (u16)sum/N;
}




