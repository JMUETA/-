#ifndef __DATATY_H__
#define __DATATY_H__

typedef   signed char           int8;
typedef unsigned char           u8;
typedef unsigned char           uint8;
typedef unsigned char           byte;
typedef   signed short int      int16;
typedef unsigned short int      uint16;
typedef unsigned short int      u16;
typedef unsigned long int       u32; 


#endif


